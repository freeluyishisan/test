# docker-compose一键部署的若依前后端版

使用docker compose 部署若依前后端分离版，项目包括四个服务，mysql,redis,ruoyi-backend,ruoyi-frontend。

下载项目，确保电脑上有docker，直接进入项目根目录使用：
docker compose up -d --build 创建并启动项目
在浏览器访问：http://localhost:30080，账号admin/admin123